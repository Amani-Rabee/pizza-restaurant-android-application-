package com.birzeit.androidproject;

public class Order {
    private int id;
    private String email;
    private String pizzaType;
    private String pizzaSize;
    private int quantity;
    private double totalPrice;
    private String orderDate;

    public Order(int id, String email, String pizzaType, String pizzaSize, int quantity, double totalPrice, String orderDate) {
        this.id = id;
        this.email = email;
        this.pizzaType = pizzaType;
        this.pizzaSize = pizzaSize;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.orderDate = orderDate;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getPizzaType() {
        return pizzaType;
    }

    public String getPizzaSize() {
        return pizzaSize;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public String getOrderDate() {
        return orderDate;
    }
}
