package com.birzeit.androidproject;

import java.io.Serializable;

public class Pizza implements Serializable {
    private String type;
    private double price;
    private String size;
    private long id;
    private String category;
    private boolean isFavorite;

    public Pizza()
    {}
    public Pizza( String type, String category, boolean isFavorite) {

        this.type=type;
        this.category= category;

        this.isFavorite=isFavorite;
    }

    public Pizza(int pizzaId, String name, String description, String category) {
        this.id = pizzaId;
        this.type = name;
        this.category = category;
    }




    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }
    public String getImageName() {
        return type.toLowerCase().replace(" ", "_") + ".png";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Pizza{" +
                "type='" + type + '\'' +
                ", price=" + price +
                ", size='" + size + '\'' +
                ", category='" + category + '\'' +
                ", isFavorite=" + isFavorite +
                '}';
    }
}
