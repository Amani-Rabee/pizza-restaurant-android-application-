package com.birzeit.androidproject;

import java.io.Serializable;

public class SpecialOffer implements Serializable {

    private String pizzaName;
    private String pizzaCategory;
    private double originalPrice;
    private double offerPrice;
    private int pizzaImage;
    private String startDate;
    private String endDate;

    public SpecialOffer(String pizzaName, String pizzaCategory, double originalPrice, double offerPrice, int pizzaImage) {
        this.pizzaName = pizzaName;
        this.pizzaCategory = pizzaCategory;
        this.originalPrice = originalPrice;
        this.offerPrice = offerPrice;
        this.pizzaImage = pizzaImage;
    }

    public String getPizzaName() {
        return pizzaName;
    }

    public String getPizzaCategory() {
        return pizzaCategory;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }

    public double getOfferPrice() {
        return offerPrice;
    }

    public int getPizzaImage() {
        return pizzaImage;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
