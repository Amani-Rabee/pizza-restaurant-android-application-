package com.birzeit.androidproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.FavoritesViewHolder> {

    private List<Pizza> favoritesList;
    private Context context;
    private String userEmail;
    private UserDataBase userDataBase; // Add a UserDataBase reference

    public FavoritesAdapter(List<Pizza> favoritesList, Context context, String userEmail) {
        this.favoritesList = favoritesList;
        this.context = context;
        this.userEmail = userEmail;
        this.userDataBase = new UserDataBase(context); // Initialize UserDataBase
    }

    @NonNull
    @Override
    public FavoritesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.items_favorite, parent, false);
        return new FavoritesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoritesViewHolder holder, int position) {
        Pizza pizza = favoritesList.get(position);
        holder.bind(pizza);
    }

    @Override
    public int getItemCount() {
        return favoritesList.size();
    }

    class FavoritesViewHolder extends RecyclerView.ViewHolder {

        TextView pizzaName, pizzaCategory, pizzaPrice;
        ImageButton favoriteButton;
        ImageView pizzaImage;
        Animation slideOutAnimation; // Animation reference

        public FavoritesViewHolder(@NonNull View itemView) {
            super(itemView);
            pizzaName = itemView.findViewById(R.id.pizza_name);
            pizzaCategory = itemView.findViewById(R.id.pizza_category);
            pizzaPrice = itemView.findViewById(R.id.pizza_price);
            favoriteButton = itemView.findViewById(R.id.favorite_button);
            pizzaImage = itemView.findViewById(R.id.pizza_image);

            // Optional: Load slide-out animation
            slideOutAnimation = AnimationUtils.loadAnimation(context, R.anim.slide_out_left);
        }

        public void bind(Pizza pizza) {
            pizzaName.setText(pizza.getType());
            pizzaPrice.setText(String.valueOf(pizza.getPrice()));

            // Load pizza image dynamically based on the pizza type
            switch (pizza.getType()) {
                case "Margarita":
                    pizzaImage.setImageResource(R.drawable.margarita);
                    break;
                case "Neapolitan":
                    pizzaImage.setImageResource(R.drawable.neapolitan);
                    break;
                case "Hawaiian":
                    pizzaImage.setImageResource(R.drawable.hawaiian);
                    break;
                case "Pepperoni":
                    pizzaImage.setImageResource(R.drawable.pepperoni);
                    break;
                case "New York Style":
                    pizzaImage.setImageResource(R.drawable.new_ynework_style);
                    break;
                case "Calzone":
                    pizzaImage.setImageResource(R.drawable.calzone);
                    break;
                case "Tandoori Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.tandoori_chicken_pizza);
                    break;
                case "BBQ Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.bbq_chicken_pizza);
                    break;
                case "Seafood Pizza":
                    pizzaImage.setImageResource(R.drawable.seafood_pizza);
                    break;
                case "Vegetarian Pizza":
                    pizzaImage.setImageResource(R.drawable.vegetarian_pizza);
                    break;
                case "Buffalo Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.buffalo_hicken_pizza);
                    break;
                case "Mushroom Truffle Pizza":
                    pizzaImage.setImageResource(R.drawable.mushroom_truffle_pizza);
                    break;
                case "Pesto Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.pesto_chicken_pizza);
                    break;
                default:
                    // Set a default image if the pizza type is not recognized
                    pizzaImage.setImageResource(R.drawable.pizza_logo);
                    break;
            }

            // Set favorite button state
            favoriteButton.setImageResource(R.drawable.favorite_fill);

            favoriteButton.setOnClickListener(v -> {
                pizza.setFavorite(false);
                userDataBase.updatePizzaFavoriteStatus(userEmail, pizza);

                // Animate the removal
                animateRemoval();
            });
        }

        private void animateRemoval() {
            slideOutAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    // Animation started
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    // Animation ended, remove item from list and notify adapter
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        favoritesList.remove(position);
                        notifyItemRemoved(position);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                    // Animation repeated
                }
            });

            itemView.startAnimation(slideOutAnimation);
        }
    }
}
