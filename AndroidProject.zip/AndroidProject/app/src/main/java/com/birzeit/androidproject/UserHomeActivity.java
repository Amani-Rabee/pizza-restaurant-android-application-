package com.birzeit.androidproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class UserHomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;


    private UserDataBase dataBaseHelper;

    public Toolbar toolbar;
    public static NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        dataBaseHelper = new UserDataBase(this);

        // Retrieve user data from intent
        Intent intent = getIntent();
        String fullName = intent.getStringExtra("fullName");
        String email = intent.getStringExtra("email");

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Set nav header based on user information
        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = headerView.findViewById(R.id.user_name);
        TextView navEmail = headerView.findViewById(R.id.user_email);
        navUsername.setText(fullName);
        navEmail.setText(email);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("HOME");
        toolbar.setTitleTextColor(Color.parseColor("#FFFFFFFF"));
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_nav, R.string.close_nav);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        navigationView.setCheckedItem(R.id.nav_home);

    }

    @Override
    public void onBackPressed(){
        if (drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.nav_profile ){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("USER PROFILE");


            UserProfileFragment userProfileFragment = new UserProfileFragment();
            Bundle bundle = new Bundle();
            Intent intent = getIntent();
            String email = intent.getStringExtra("email"); // Assume the email was passed to this activity through an Intent
            bundle.putString("userEmail", email);
            userProfileFragment.setArguments(bundle);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, userProfileFragment)
                    .commit();
        }
        if (item.getItemId()==R.id.nav_home){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("HOME");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit();
        }
        if (item.getItemId()==R.id.nav_favorites){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("MY FAVORITE");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new FavoritesFragment()).commit();
        }
        if (item.getItemId()==R.id.nav_orders){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("ORDER HISTORY");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new OrdersFragment()).commit();
        }
        if (item.getItemId()==R.id.nav_offers){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("OFFERS");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new SpecialOffersFragment()).commit();
        }
        if (item.getItemId()==R.id.nav_contact){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("Contact");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new ContactFragment()).commit();
        }
        if (item.getItemId()==R.id.nav_logout){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            StringBuilder details = new StringBuilder();
            details.append("Are you sure you want to logout?");

            AlertDialog.Builder builder = new AlertDialog.Builder(UserHomeActivity.this);
            builder.setTitle("Confirm Logout")
                    .setMessage(details.toString())
                    .setNegativeButton("cancel",null)
                    .setPositiveButton("sure", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent intent = new Intent(UserHomeActivity.this, UserLogInActivity.class);
                            UserHomeActivity.this.startActivity(intent);
                            finish();
                        }
                    })
                    .create()
                    .show();
        }
        if (item.getItemId()==R.id.nav_pizza_menu){
            toolbar.setBackgroundColor(Color.parseColor("#00897B"));
            toolbar.setTitle("Pizza MENU");
            drawer.closeDrawer(GravityCompat.START);

            // thread to not make the app freeze
            new Thread(() -> runOnUiThread(()->{
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new PizzaMenuFragment()).commit();
            })).start();
        }


        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



}