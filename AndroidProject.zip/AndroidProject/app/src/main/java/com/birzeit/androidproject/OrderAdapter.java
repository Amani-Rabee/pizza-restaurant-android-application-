package com.birzeit.androidproject;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private Context context;

    public OrderAdapter(List<Order> orderList, Context context) {
        this.orderList = orderList;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.items_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);
        holder.bind(order);

        // Set click listener to navigate to order details fragment
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pass the selected order to navigateToOrderDetails method
                navigateToOrderDetails(order);
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    class OrderViewHolder extends RecyclerView.ViewHolder {

        TextView pizzaType, totalPrice, orderDate;
        ImageView pizzaImage;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            pizzaType = itemView.findViewById(R.id.pizza_name_order);
            totalPrice = itemView.findViewById(R.id.ordered_pizza_price);
            orderDate = itemView.findViewById(R.id.order_date);
            pizzaImage = itemView.findViewById(R.id.pizza_image_order);
        }

        public void bind(Order order) {
            pizzaType.setText(order.getPizzaType());
            totalPrice.setText(String.format("$%.2f", order.getTotalPrice()));
            orderDate.setText(order.getOrderDate());
            switch (order.getPizzaType()) {
                case "Margarita":
                    pizzaImage.setImageResource(R.drawable.margarita);
                    break;
                case "Neapolitan":
                    pizzaImage.setImageResource(R.drawable.neapolitan);
                    break;
                case "Hawaiian":
                    pizzaImage.setImageResource(R.drawable.hawaiian);
                    break;
                case "Pepperoni":
                    pizzaImage.setImageResource(R.drawable.pepperoni);
                    break;
                case "New York Style":
                    pizzaImage.setImageResource(R.drawable.new_ynework_style);
                    break;
                case "Calzone":
                    pizzaImage.setImageResource(R.drawable.calzone);
                    break;
                case "Tandoori Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.tandoori_chicken_pizza);
                    break;
                case "BBQ Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.bbq_chicken_pizza);
                    break;
                case "Seafood Pizza":
                    pizzaImage.setImageResource(R.drawable.seafood_pizza);
                    break;
                case "Vegetarian Pizza":
                    pizzaImage.setImageResource(R.drawable.vegetarian_pizza);
                    break;
                case "Buffalo Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.buffalo_hicken_pizza);
                    break;
                case "Mushroom Truffle Pizza":
                    pizzaImage.setImageResource(R.drawable.mushroom_truffle_pizza);
                    break;
                case "Pesto Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.pesto_chicken_pizza);
                    break;
                default:
                    pizzaImage.setImageResource(R.drawable.pizza_logo);
                    break;
            }
        }
    }

    private void navigateToOrderDetails(Order order) {
        OrderDetailsFragment orderDetailsFragment = new OrderDetailsFragment();
        Bundle args = new Bundle();
        args.putString("pizzaType", order.getPizzaType());
        args.putString("pizzaSize", order.getPizzaSize());
        args.putInt("quantity", order.getQuantity());
        args.putDouble("totalPrice", order.getTotalPrice());
        args.putString("orderDate", order.getOrderDate());
        orderDetailsFragment.setArguments(args);

        // Use getChildFragmentManager() if you are in a fragment
        FragmentTransaction transaction = ((AppCompatActivity) context).getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, orderDetailsFragment);
        transaction.addToBackStack(null);  // Optional: Add fragment to back stack
        transaction.commit();
    }
}
