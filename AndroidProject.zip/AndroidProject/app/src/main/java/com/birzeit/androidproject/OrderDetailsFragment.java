package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

public class OrderDetailsFragment extends Fragment {

    private TextView pizzaTypeTextView, pizzaSizeTextView, quantityTextView, totalPriceTextView, orderDateTextView;
    private ImageView pizzaImage;
    public OrderDetailsFragment() {
        // Required empty public constructor
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order_details, container, false);

        // Initialize TextViews
        pizzaTypeTextView = view.findViewById(R.id.pizza_type);
        pizzaSizeTextView = view.findViewById(R.id.pizza_size);
        quantityTextView = view.findViewById(R.id.quantity);
        totalPriceTextView = view.findViewById(R.id.total_price);
        orderDateTextView = view.findViewById(R.id.order_date);
        pizzaImage=view.findViewById(R.id.pizza_image_order_details);
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null) {
            Toolbar toolbar = activity.findViewById(R.id.toolbar);
            toolbar.setTitle("ORDER DETAILS");
            toolbar.setBackgroundColor(Color.parseColor("#FFFFFF"));
            toolbar.setTitleTextColor(Color.parseColor("black"));
        }
        // Retrieve order details from arguments
        Bundle arguments = getArguments();
        if (arguments != null) {
            String pizzaType = arguments.getString("pizzaType");
            String pizzaSize = arguments.getString("pizzaSize");
            int quantity = arguments.getInt("quantity");
            double totalPrice = arguments.getDouble("totalPrice");
            String orderDate = arguments.getString("orderDate");

            // Display order details
            pizzaTypeTextView.setText(pizzaType);
            pizzaSizeTextView.setText(pizzaSize);
            quantityTextView.setText(String.valueOf(quantity));
            totalPriceTextView.setText(String.format("$%.2f", totalPrice));
            orderDateTextView.setText(orderDate);
            switch (pizzaType) {
                case "Margarita":
                    pizzaImage.setImageResource(R.drawable.margarita);
                    break;
                case "Neapolitan":
                    pizzaImage.setImageResource(R.drawable.neapolitan);
                    break;
                case "Hawaiian":
                    pizzaImage.setImageResource(R.drawable.hawaiian);
                    break;
                case "Pepperoni":
                    pizzaImage.setImageResource(R.drawable.pepperoni);
                    break;
                case "New York Style":
                    pizzaImage.setImageResource(R.drawable.new_ynework_style);
                    break;
                case "Calzone":
                    pizzaImage.setImageResource(R.drawable.calzone);
                    break;
                case "Tandoori Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.tandoori_chicken_pizza);
                    break;
                case "BBQ Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.bbq_chicken_pizza);
                    break;
                case "Seafood Pizza":
                    pizzaImage.setImageResource(R.drawable.seafood_pizza);
                    break;
                case "Vegetarian Pizza":
                    pizzaImage.setImageResource(R.drawable.vegetarian_pizza);
                    break;
                case "Buffalo Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.buffalo_hicken_pizza);
                    break;
                case "Mushroom Truffle Pizza":
                    pizzaImage.setImageResource(R.drawable.mushroom_truffle_pizza);
                    break;
                case "Pesto Chicken Pizza":
                    pizzaImage.setImageResource(R.drawable.pesto_chicken_pizza);
                    break;
                default:
                    pizzaImage.setImageResource(R.drawable.pizza_logo);
                    break;
            }
        }
        ImageView backButton = view.findViewById(R.id.backButtonOrder);
        backButton.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
