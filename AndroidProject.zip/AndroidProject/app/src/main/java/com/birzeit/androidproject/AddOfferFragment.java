package com.birzeit.androidproject;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddOfferFragment extends Fragment {

    private Spinner spinnerPizzaNames;
    private RadioGroup radioGroupSizes;
    private EditText editTextTotalPrice;
    private EditText editTextStartDate;
    private EditText editTextEndDate;
    private Button buttonAddOffer;

    private UserDataBase userDataBase;
    private List<Pizza> pizzaList;
    private String selectedSize;
    private long selectedPizzaId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_offer, container, false);

        spinnerPizzaNames = view.findViewById(R.id.spinnerPizzaNames);
        radioGroupSizes = view.findViewById(R.id.radioGroupSizes);
        editTextTotalPrice = view.findViewById(R.id.editTextTotalPrice);
        editTextStartDate = view.findViewById(R.id.editTextStartDate);
        editTextEndDate = view.findViewById(R.id.editTextEndDate);
        buttonAddOffer = view.findViewById(R.id.buttonAddOffer);

        userDataBase = new UserDataBase(getContext());

        loadPizzaNames();

        radioGroupSizes.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton radioButton = group.findViewById(checkedId);
            if (radioButton != null) {
                selectedSize = radioButton.getText().toString();
            }
        });

        editTextStartDate.setOnClickListener(v -> showDatePickerDialog(editTextStartDate));

        editTextEndDate.setOnClickListener(v -> showDatePickerDialog(editTextEndDate));

        buttonAddOffer.setOnClickListener(v -> addOffer());

        return view;
    }

    private void loadPizzaNames() {
        pizzaList = MainActivity.pizzaTypes;
        List<String> pizzaNames = new ArrayList<>();
        for (Pizza pizza : pizzaList) {
            pizzaNames.add(pizza.getType());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, pizzaNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPizzaNames.setAdapter(adapter);

        spinnerPizzaNames.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPizzaId = pizzaList.get(position).getId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedPizzaId = -1;
            }
        });
    }

    private void showDatePickerDialog(final EditText editText) {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String date = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                        editText.setText(date);
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void addOffer() {
        String totalPriceStr = editTextTotalPrice.getText().toString();
        String startDateStr = editTextStartDate.getText().toString();
        String endDateStr = editTextEndDate.getText().toString();

        if (selectedPizzaId == -1 || selectedSize == null || totalPriceStr.isEmpty() || startDateStr.isEmpty() || endDateStr.isEmpty()) {
            Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate end date is after start date
        if (!isEndDateValid(startDateStr, endDateStr)) {
            Toast.makeText(getContext(), "End date cannot be before or equal to start date", Toast.LENGTH_SHORT).show();
            return;
        }

        double discount = Double.parseDouble(totalPriceStr);

        userDataBase.addOffer(selectedPizzaId, selectedSize, discount, startDateStr, endDateStr);
        Toast.makeText(getContext(), "Offer added successfully", Toast.LENGTH_SHORT).show();

        // Clear fields after adding the offer
        spinnerPizzaNames.setSelection(0);
        radioGroupSizes.clearCheck();
        editTextTotalPrice.setText("");
        editTextStartDate.setText("");
        editTextEndDate.setText("");
    }

    private boolean isEndDateValid(String startDateStr, String endDateStr) {
        try {
            Calendar startCalendar = Calendar.getInstance();
            Calendar endCalendar = Calendar.getInstance();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

            startCalendar.setTime(dateFormat.parse(startDateStr));
            endCalendar.setTime(dateFormat.parse(endDateStr));

            // Check if end date is after start date
            return !endCalendar.before(startCalendar);
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Consider parsing error as invalid date
        }
    }
}
