package com.birzeit.androidproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.function.Consumer;

public class PizzaAdapter extends RecyclerView.Adapter<PizzaAdapter.PizzaViewHolder> {

    private ArrayList<Pizza> pizzaList;
    private Context context;
    private Consumer<Pizza> onPizzaClickListener;
    private Consumer<Pizza> onAddToFavoritesClickListener;
    private Consumer<Pizza> onOrderClickListener;

    public PizzaAdapter(ArrayList<Pizza> pizzaList, Context context,
                        Consumer<Pizza> onPizzaClickListener,
                        Consumer<Pizza> onAddToFavoritesClickListener,
                        Consumer<Pizza> onOrderClickListener) {
        this.pizzaList = pizzaList;
        this.context = context;
        this.onPizzaClickListener = onPizzaClickListener;
        this.onAddToFavoritesClickListener = onAddToFavoritesClickListener;
        this.onOrderClickListener = onOrderClickListener;
    }

    @NonNull
    @Override
    public PizzaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pizza, parent, false);
        return new PizzaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PizzaViewHolder holder, int position) {
        Pizza pizza = pizzaList.get(position);
        holder.bind(pizza);

        // Load pizza image dynamically based on the pizza type
        switch (pizza.getType()) {
            case "Margarita":
                holder.pizzaImage.setImageResource(R.drawable.margarita);
                break;
            case "Neapolitan":
                holder.pizzaImage.setImageResource(R.drawable.neapolitan);
                break;
            case "Hawaiian":
                holder.pizzaImage.setImageResource(R.drawable.hawaiian);
                break;
            case "Pepperoni":
                holder.pizzaImage.setImageResource(R.drawable.pepperoni);
                break;
            case "New York Style":
                holder.pizzaImage.setImageResource(R.drawable.new_ynework_style);
                break;
            case "Calzone":
                holder.pizzaImage.setImageResource(R.drawable.calzone);
                break;
            case "Tandoori Chicken Pizza":
                holder.pizzaImage.setImageResource(R.drawable.tandoori_chicken_pizza);
                break;
            case "BBQ Chicken Pizza":
                holder.pizzaImage.setImageResource(R.drawable.bbq_chicken_pizza);
                break;
            case "Seafood Pizza":
                holder.pizzaImage.setImageResource(R.drawable.seafood_pizza);
                break;
            case "Vegetarian Pizza":
                holder.pizzaImage.setImageResource(R.drawable.vegetarian_pizza);
                break;
            case "Buffalo Chicken Pizza":
                holder.pizzaImage.setImageResource(R.drawable.buffalo_hicken_pizza);
                break;
            case "Mushroom Truffle Pizza":
                holder.pizzaImage.setImageResource(R.drawable.mushroom_truffle_pizza);
                break;
            case "Pesto Chicken Pizza":
                holder.pizzaImage.setImageResource(R.drawable.pesto_chicken_pizza);
                break;

            default:
                // Set a default image if the pizza type is not recognized
                holder.pizzaImage.setImageResource(R.drawable.pizza_logo);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return pizzaList.size();
    }

    public void updateList(ArrayList<Pizza> newList) {
        pizzaList = newList;
        notifyDataSetChanged();
    }

    class PizzaViewHolder extends RecyclerView.ViewHolder {

        ImageView pizzaImage;
        TextView pizzaName, pizzaCategory, pizzaPrice;
        ImageButton favoriteButton;
        ImageView addImageView;

        public PizzaViewHolder(@NonNull View itemView) {
            super(itemView);
            pizzaImage = itemView.findViewById(R.id.pizza_image);
            pizzaName = itemView.findViewById(R.id.pizza_name);
            pizzaCategory = itemView.findViewById(R.id.pizza_category);
            pizzaPrice = itemView.findViewById(R.id.pizza_price);
            favoriteButton = itemView.findViewById(R.id.favorite_button);
            addImageView = itemView.findViewById(R.id.addImageView);
        }

        public void bind(Pizza pizza) {
            pizzaName.setText(pizza.getType());
            pizzaCategory.setText(pizza.getCategory());
            pizzaPrice.setText(String.format("$%.2f", pizza.getPrice()));

            // Set the favorite button state
            favoriteButton.setImageResource(pizza.isFavorite() ? R.drawable.favorite_fill : R.drawable.favourite_not_fill);

            favoriteButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100);
                            onAddToFavoritesClickListener.accept(pizza);
                        }
                    });
                }
            });
            addImageView.setOnClickListener(v -> onOrderClickListener.accept(pizza));
            itemView.setOnClickListener(v -> onPizzaClickListener.accept(pizza));
        }

        private void animateFavoriteButton() {
            Animation scaleAnimation = AnimationUtils.loadAnimation(context, R.anim.scale_up);
            favoriteButton.startAnimation(scaleAnimation);
        }
    }
}
