package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class OfferDetailsFragment extends Fragment {

    private static final String ARG_SPECIAL_OFFER = "special_offer";
    private SpecialOffer specialOffer;
    private String userEmail;
    private UserDataBase dataBaseHelper;
    private int quantity = 1;
    private TextView quantityTextView, pizzaPrice, offerPrice, endDate, countdownTextView;
    private ImageView backButton;

    public static OfferDetailsFragment newInstance(SpecialOffer specialOffer) {
        OfferDetailsFragment fragment = new OfferDetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_SPECIAL_OFFER, specialOffer);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            specialOffer = (SpecialOffer) getArguments().getSerializable(ARG_SPECIAL_OFFER);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_offer_details, container, false);
        userEmail = getActivity().getIntent().getStringExtra("email");
        dataBaseHelper = new UserDataBase(getContext());

        // Initialize UI elements and set offer details
        TextView pizzaName = view.findViewById(R.id.pizzaName);
        offerPrice = view.findViewById(R.id.offerPriceDetailed);
        endDate = view.findViewById(R.id.endDateDetailed);
        countdownTextView = view.findViewById(R.id.countdownDetailed);
        ImageView pizzaImage = view.findViewById(R.id.pizza_image_detailed);
        quantityTextView = view.findViewById(R.id.quantityDetailed);

        pizzaName.setText(specialOffer.getPizzaName());
        updatePizzaPrice();

        offerPrice.setText(String.format("$%.2f", specialOffer.getOfferPrice()));
        endDate.setText("End Date: " + specialOffer.getEndDate());

        // Load pizza image dynamically based on the pizza type
        int imageResource;
        switch (specialOffer.getPizzaName()) {
            case "Margarita":
                imageResource = R.drawable.margarita;
                break;
            case "Neapolitan":
                imageResource = R.drawable.neapolitan;
                break;
            case "Hawaiian":
                imageResource = R.drawable.hawaiian;
                break;
            case "Pepperoni":
                imageResource = R.drawable.pepperoni;
                break;
            case "New York Style":
                imageResource = R.drawable.new_ynework_style; // Corrected the typo in the resource name
                break;
            case "Calzone":
                imageResource = R.drawable.calzone;
                break;
            case "Tandoori Chicken Pizza":
                imageResource = R.drawable.tandoori_chicken_pizza;
                break;
            case "BBQ Chicken Pizza":
                imageResource = R.drawable.bbq_chicken_pizza;
                break;
            case "Seafood Pizza":
                imageResource = R.drawable.seafood_pizza;
                break;
            case "Vegetarian Pizza":
                imageResource = R.drawable.vegetarian_pizza;
                break;
            case "Buffalo Chicken Pizza":
                imageResource = R.drawable.buffalo_hicken_pizza; // Corrected the typo in the resource name
                break;
            case "Mushroom Truffle Pizza":
                imageResource = R.drawable.mushroom_truffle_pizza;
                break;
            case "Pesto Chicken Pizza":
                imageResource = R.drawable.pesto_chicken_pizza;
                break;
            default:
                imageResource = R.drawable.pizza_logo;
                break;
        }
        pizzaImage.setImageResource(imageResource);

        // Setup quantity buttons
        Button increaseQuantity = view.findViewById(R.id.increaseQuantityDetailed);
        Button decreaseQuantity = view.findViewById(R.id.decreaseQuantityDetailed);

        increaseQuantity.setOnClickListener(v -> {
            quantity++;
            quantityTextView.setText(String.valueOf(quantity));
            updatePizzaPrice();
        });

        decreaseQuantity.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                quantityTextView.setText(String.valueOf(quantity));
                updatePizzaPrice();
            }
        });
// Handle back button click
        backButton = view.findViewById(R.id.backButtonOffer);
        backButton.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().popBackStack();
        });
        // Setup order button
        Button orderButton = view.findViewById(R.id.makeOrderDetailed);
        orderButton.setOnClickListener(v -> {
            String orderDetails = "Pizza: " + specialOffer.getPizzaName() + "\n" +
                    "Quantity: " + quantity + "\n" +
                    "Total Price: $" + specialOffer.getOfferPrice() * quantity;

            // Show order details in a dialog
            new AlertDialog.Builder(getContext())
                    .setTitle("Order Confirmation")
                    .setMessage(orderDetails)
                    .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            placeOrder();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Setup countdown timer
        startCountdown();

        return view;
    }

    @SuppressLint("DefaultLocale")
    private void startCountdown() {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date endDate = dateFormat.parse(specialOffer.getEndDate());
            if (endDate != null) {
                long endTimeInMillis = endDate.getTime();
                long currentTimeInMillis = System.currentTimeMillis();
                long timeLeftInMillis = endTimeInMillis - currentTimeInMillis;

                if (timeLeftInMillis > 0) {
                    new CountDownTimer(timeLeftInMillis, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {
                            long days = TimeUnit.MILLISECONDS.toDays(millisUntilFinished);
                            long hours = TimeUnit.MILLISECONDS.toHours(millisUntilFinished) % 24;
                            long minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % 60;
                            long seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % 60;

                            countdownTextView.setText(String.format("Countdown: %02d:%02d:%02d:%02d", days, hours, minutes, seconds));
                        }

                        @Override
                        public void onFinish() {
                            countdownTextView.setText("Offer has ended");
                        }
                    }.start();
                } else {
                    countdownTextView.setText("Offer has ended");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            countdownTextView.setText("Countdown: Error");
        }
    }

    private void updatePizzaPrice() {
        double total = specialOffer.getOfferPrice() * quantity;
        offerPrice.setText(String.format("$%.2f", total));
    }

    private void placeOrder() {
        // Insert the order into the database or perform any other action here
        dataBaseHelper.insertOrder(userEmail, specialOffer.getPizzaName(),specialOffer.getPizzaCategory(), quantity, specialOffer.getOfferPrice() * quantity);
        Toast.makeText(getContext(), "Order placed successfully!", Toast.LENGTH_SHORT).show();
    }
}
