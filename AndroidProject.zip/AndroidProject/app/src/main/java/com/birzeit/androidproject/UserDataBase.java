package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.util.Pair;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class UserDataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ProjData";
    private static final int DATABASE_VERSION = 1;

    public UserDataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create Users table
        sqLiteDatabase.execSQL("CREATE TABLE Users (" +
                "email TEXT PRIMARY KEY," +
                "password TEXT NOT NULL," +
                "first_name TEXT NOT NULL," +
                "last_name TEXT NOT NULL," +
                "phone_number TEXT NOT NULL," +
                "gender TEXT," +
                "is_admin BOOLEAN NOT NULL DEFAULT 0)");

        // Create Pizzas table
        sqLiteDatabase.execSQL("CREATE TABLE Pizzas (" +
                "pizza_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "description TEXT," +
                "category TEXT)");

        sqLiteDatabase.execSQL("CREATE TABLE PizzaSizes (" +
                "pizza_size_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pizza_id INTEGER NOT NULL," +
                "size TEXT NOT NULL," +
                "price REAL NOT NULL," +
                "quantity INTEGER NOT NULL DEFAULT 0," + // New column for quantity
                "FOREIGN KEY (pizza_id) REFERENCES Pizzas(pizza_id))");



            sqLiteDatabase.execSQL("CREATE TABLE Orders (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "email TEXT, " +
                    "pizza_type TEXT, " +
                    "pizza_size TEXT, " +
                    "quantity INTEGER, " +
                    "total_price REAL, " +
                    "order_date TEXT)");


        // Create Favorites table
        sqLiteDatabase.execSQL("CREATE TABLE Favorites (" +
                "favorite_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT NOT NULL," +
                "pizza_type TEXT NOT NULL," +
                "FOREIGN KEY (email) REFERENCES Users(email))");

        // Create SpecialOffers table
        sqLiteDatabase.execSQL("CREATE TABLE Offers (" +
                "offer_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pizza_id LONG NOT NULL," +
                "size TEXT NOT NULL," +
                "total_price REAL NOT NULL," +
                "start_date TEXT NOT NULL," +
                "end_date TEXT NOT NULL," +
                "FOREIGN KEY (pizza_id) REFERENCES Pizzas(pizza_id))");

        String CREATE_PIZZA_MENU_TABLE = "CREATE TABLE PizzaMenu (" +
                "email TEXT, " +
                "type TEXT, " +
                "price REAL, " +
                "size TEXT, " +
                "category TEXT, " +
                "favorite INTEGER)";
        sqLiteDatabase.execSQL(CREATE_PIZZA_MENU_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // Drop all tables if they exist
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Users");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Pizzas");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS PizzaSizes");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Orders");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS OrderDetails");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Favorites");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS SpecialOffers");

        // Create new tables
        onCreate(sqLiteDatabase);
    }
    public void insertUser(String email, String password, String firstName, String lastName, String phoneNumber, String gender, boolean isAdmin) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("first_name", firstName);
        contentValues.put("last_name", lastName);
        contentValues.put("phone_number", phoneNumber);
        contentValues.put("gender", gender);
        contentValues.put("is_admin", isAdmin);
        sqLiteDatabase.insert("Users", null, contentValues);
    }
    public Cursor getUser(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM Users WHERE email = ?", new String[]{email});
    }
    public boolean checkUserExists(String email) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM Users WHERE email = ?", new String[]{email});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }
    public List<Order> getOrderHistory(String email) {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Orders WHERE email = ?", new String[]{email});

        Log.d("UserDataBase", "Query executed: SELECT * FROM Orders WHERE email = " + email);

        if (cursor.moveToFirst()) {
            Log.d("UserDataBase", "Orders found for email: " + email);
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String pizzaType = cursor.getString(cursor.getColumnIndexOrThrow("pizza_type"));
                String pizzaSize = cursor.getString(cursor.getColumnIndexOrThrow("pizza_size"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                double totalPrice = cursor.getDouble(cursor.getColumnIndexOrThrow("total_price"));
                String orderDate = cursor.getString(cursor.getColumnIndexOrThrow("order_date"));

                Log.d("UserDataBase", "Order found: " + pizzaType + ", " + pizzaSize + ", " + quantity + ", " + totalPrice + ", " + orderDate);

                Order order = new Order(id, email, pizzaType, pizzaSize, quantity, totalPrice, orderDate);
                orderList.add(order);
            } while (cursor.moveToNext());
        } else {
            Log.d("UserDataBase", "No orders found for email: " + email);
        }

        cursor.close();
        return orderList;
    }
    public void insertPizzasForUser(String email, List<Pizza> pizzas) {
        SQLiteDatabase db = this.getWritableDatabase();
        int i=1;
        for (Pizza pizza : pizzas) {
            ContentValues values = new ContentValues();
            values.put("email", email);
            values.put("type", pizza.getType());
            values.put("price", pizza.getPrice());
            values.put("size", pizza.getSize());
            values.put("category", pizza.getCategory());
            values.put("favorite", pizza.isFavorite() ? 1 : 0);
            db.insert("PizzaMenu", null, values);
            pizza.setId(i++);
        }
    }
    public List<Pizza> getPizzasForUser(String email) {
        List<Pizza> pizzaList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("PizzaMenu", null, "email=?", new String[]{email}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
                double price = cursor.getDouble(cursor.getColumnIndexOrThrow("price"));
                String size = cursor.getString(cursor.getColumnIndexOrThrow("size"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                boolean favorite = cursor.getInt(cursor.getColumnIndexOrThrow("favorite")) == 1;

                Pizza pizza = new Pizza();
                pizza.setType(type);
                pizza.setPrice(price);
                pizza.setSize(size);
                pizza.setCategory(category);
                pizza.setFavorite(favorite);
                pizzaList.add(pizza);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return pizzaList;
    }
    public void insertOrder(String email, String pizzaType, String pizzaSize, int quantity, double totalPrice) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("pizza_type", pizzaType);
        contentValues.put("pizza_size", pizzaSize);
        contentValues.put("quantity", quantity);
        contentValues.put("total_price", totalPrice);
        contentValues.put("order_date", new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        long result = sqLiteDatabase.insert("Orders", null, contentValues);

        if(result == -1) {
            Log.d("UserDataBase", "Order insertion failed for email: " + email);
        } else {
            Log.d("UserDataBase", "Order inserted successfully for email: " + email);
        }
    }
    public List<Pizza> getFavoritePizzas(String email) {
        List<Pizza> favoritePizzas = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT PizzaMenu.type, PizzaMenu.price, PizzaMenu.size, PizzaMenu.category " +
                "FROM PizzaMenu " +
                "WHERE PizzaMenu.email = ? AND PizzaMenu.favorite = 1";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        Log.d("UserDataBase", "Query executed: " + query);

        if (cursor.moveToFirst()) {
            Log.d("UserDataBase", "Favorites found for email: " + email);
            do {
                String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
                double price = cursor.getDouble(cursor.getColumnIndexOrThrow("price"));
                String size = cursor.getString(cursor.getColumnIndexOrThrow("size"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));


                Log.d("UserDataBase", "Favorite found: " + type + ", "  + category);

                Pizza pizza = new Pizza(type, category, true);
                pizza.setPrice(price);
                pizza.setSize(size);

                favoritePizzas.add(pizza);
            } while (cursor.moveToNext());
        } else {
            Log.d("UserDataBase", "No favorites found for email: " + email);
        }

        cursor.close();
        return favoritePizzas;
    }
    public void updatePizzaFavoriteStatus(String userEmail, Pizza pizza) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("favorite", pizza.isFavorite() ? 1 : 0);
        sqLiteDatabase.update("PizzaMenu", contentValues, "email = ? AND type = ?", new String[]{userEmail, pizza.getType()});
    }
    public void insertPizzaSize(long pizzaId, String size, double price, int quantity) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("pizza_id", pizzaId);
        contentValues.put("size", size);
        contentValues.put("price", price);
        contentValues.put("quantity", quantity); // Include quantity in the insert statement
        sqLiteDatabase.insert("PizzaSizes", null, contentValues);
    }
    public void insertFavoritePizza(String email, String type) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("pizza_type", type);
        sqLiteDatabase.insert("Favorites", null, contentValues);
    }
    public double getTotalIncomeForAllPizzaTypes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(total_price) FROM Orders", null);
        double totalIncome = 0.0;

        if (cursor.moveToFirst()) {
            totalIncome = cursor.getDouble(0); // Retrieve the sum directly
        }

        cursor.close();
        return totalIncome;
    }
    public int getOrdersCountForAllPizzaTypes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM Orders", null);
        int ordersCount = 0;

        if (cursor.moveToFirst()) {
            ordersCount = cursor.getInt(0); // Retrieve the count directly
        }

        cursor.close();
        return ordersCount;
    }

    public void insertInitialAdmin() {
        SQLiteDatabase dba = this.getWritableDatabase();
        if (!isAdmin(dba, "noorhamayel@admin.com")) {
            ContentValues values = new ContentValues();
            values.put("email", "noorhamayel@admin.com");
            values.put("password", hashPassword("admin123"));
            values.put("first_name", "noor");
            values.put("last_name", "hamayel");
            values.put("phone_number", "0595078334");
            values.put("gender", "Female");
            values.put("is_admin", true);
            dba.insert("Users", null, values);
        }
        dba.close();
    }
    private boolean isAdmin(SQLiteDatabase db, String email) {
        Cursor cursor = db.query("Users", new String[]{"is_admin"}, "email=?", new String[]{email}, null, null, null);
        boolean isAdmin = false;
        int isAdminIndex = cursor.getColumnIndex("is_admin"); // Get the index of the 'is_admin' column
        if (isAdminIndex != -1) { // Ensure the column index is valid
            if (cursor.moveToFirst()) {
                isAdmin = cursor.getInt(isAdminIndex) > 0; // Use the index to retrieve the value
            }
        }
        cursor.close();
        return isAdmin;
    }
    public String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e("UserDataBase", "NoSuchAlgorithmException", e);
            return null;
        }
    }
    public boolean insertAdmin(String email, String password, String firstName, String lastName, String phoneNumber, String gender, boolean isAdmin) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("password", password);
        values.put("first_name", firstName);
        values.put("last_name", lastName);
        values.put("phone_number", phoneNumber);
        values.put("gender", gender);
        values.put("is_admin", isAdmin);
        long result = db.insert("Users", null, values);
        return result != -1;
    }
    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Orders", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                String pizzaType = cursor.getString(cursor.getColumnIndexOrThrow("pizza_type"));
                String pizzaSize = cursor.getString(cursor.getColumnIndexOrThrow("pizza_size"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                double totalPrice = cursor.getDouble(cursor.getColumnIndexOrThrow("total_price"));
                String orderDate = cursor.getString(cursor.getColumnIndexOrThrow("order_date"));

                Order order = new Order(id, email, pizzaType, pizzaSize, quantity, totalPrice, orderDate);
                orderList.add(order);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return orderList;
    }
    public List<String> getAllPizzas() {
        List<String> pizzas = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Pizzas", null);

        if (cursor.moveToFirst()) {
            do {
                int pizzaId = cursor.getInt(cursor.getColumnIndexOrThrow("pizza_id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));

                Pizza pizza = new Pizza(pizzaId, name, description, category);
                pizzas.add(pizza.getType());
            } while (cursor.moveToNext());
        }

        cursor.close();
        return pizzas;
    }
    public void addOffer(long pizzaId, String size, double totalPrice, String startDate, String endDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("pizza_id", pizzaId);
        contentValues.put("size", size);
        contentValues.put("total_price", totalPrice);
        contentValues.put("start_date", startDate);
        contentValues.put("end_date", endDate);
        db.insert("Offers", null, contentValues);
    }
    public Cursor getSpecialOffers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM Offers", null);
    }

    // Method to get pizza name based on pizza_id
    @SuppressLint("Range")
    public String getPizzaName(long pizzaId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name FROM Pizzas WHERE pizza_id = ?", new String[]{String.valueOf(pizzaId)});
        String pizzaName = "";
        if (cursor.moveToFirst()) {
            pizzaName = cursor.getString(cursor.getColumnIndex("name"));
        }
        cursor.close();
        return pizzaName;
    }
    public Map<String, Pair<Integer, Double>> getPizzaOrdersSummary() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT pizza_type, SUM(quantity) as total_quantity, SUM(total_price) as total_income FROM Orders GROUP BY pizza_type";
        Cursor cursor = db.rawQuery(query, null);

        Map<String, Pair<Integer, Double>> summary = new HashMap<>();
        if (cursor.moveToFirst()) {
            do {
                String pizzaType = cursor.getString(cursor.getColumnIndexOrThrow("pizza_type"));
                int totalQuantity = cursor.getInt(cursor.getColumnIndexOrThrow("total_quantity"));
                double totalIncome = cursor.getDouble(cursor.getColumnIndexOrThrow("total_income"));

                summary.put(pizzaType, new Pair<>(totalQuantity, totalIncome));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return summary;
    }
    public int getOrdersCountForSpecificPizzaType(String pizzaType) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM Orders WHERE pizza_type = ?", new String[]{pizzaType});
        int ordersCount = 0;

        if (cursor.moveToFirst()) {
            ordersCount = cursor.getInt(0); // Retrieve the count directly
        }

        cursor.close();
        return ordersCount;
    }

    public double getTotalIncomeForSpecificPizzaType(String pizzaType) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(total_price) FROM Orders WHERE pizza_type = ?", new String[]{pizzaType});
        double totalIncome = 0.0;

        if (cursor.moveToFirst()) {
            totalIncome = cursor.getDouble(0); // Retrieve the sum directly
        }

        cursor.close();
        return totalIncome;
    }

    public String getHighestEarningPizzaType() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT pizza_type, SUM(total_price) AS total_income FROM Orders GROUP BY pizza_type ORDER BY total_income DESC LIMIT 1", null);
        String highestEarningPizza = "";

        if (cursor.moveToFirst()) {
            highestEarningPizza = cursor.getString(cursor.getColumnIndexOrThrow("pizza_type"));
        }

        cursor.close();
        return highestEarningPizza;
    }

}




