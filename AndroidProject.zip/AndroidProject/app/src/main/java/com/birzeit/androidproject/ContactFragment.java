package com.birzeit.androidproject;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class ContactFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_contact, container, false);

        Button callButton = root.findViewById(R.id.callButton);
        Button locationButton = root.findViewById(R.id.locationButton);
        Button emailButton = root.findViewById(R.id.emailButton);

        callButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:0599000000"));
            startActivity(intent);
        });

        locationButton.setOnClickListener(v -> {
            // Opening the location on Google Maps using latitude and longitude
            Uri gmmIntentUri = Uri.parse("geo:31.961013,35.190483?q=31.961013,35.190483(AdvancePizza)");
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(mapIntent);
            }
        });

        emailButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:")); // only email apps should handle this
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"AdvancePizza@Pizza.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Inquiry from App");
            if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(intent);
            }
        });

        return root;
    }
}