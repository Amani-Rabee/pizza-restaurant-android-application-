package com.birzeit.androidproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AddAdminFragment extends Fragment {

    private EditText firstName, lastName, email, phoneNumber, password, confirmPassword;
    private Spinner genderSpinner;
    private Button addAdminButton;
    private UserDataBase userDataBase;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_admin, container, false);

        initializeUI(view);
        setupGenderSpinner();
        userDataBase = new UserDataBase(getActivity());

        addAdminButton.setOnClickListener(v -> attemptAddAdmin());

        return view;
    }

    private void initializeUI(View view) {
        firstName = view.findViewById(R.id.firstName);
        lastName = view.findViewById(R.id.lastName);
        email = view.findViewById(R.id.email);
        phoneNumber = view.findViewById(R.id.phoneNumber);
        genderSpinner = view.findViewById(R.id.genderSpinner);
        password = view.findViewById(R.id.password);
        confirmPassword = view.findViewById(R.id.confirmPassword);
        addAdminButton = view.findViewById(R.id.addAdminButton);
    }

    private void setupGenderSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.gender_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(adapter);
    }

    private void attemptAddAdmin() {
        String firstNameStr = firstName.getText().toString().trim();
        String lastNameStr = lastName.getText().toString().trim();
        String emailStr = email.getText().toString().trim();
        String phoneStr = phoneNumber.getText().toString().trim();
        String gender = genderSpinner.getSelectedItem().toString();
        String passwordStr = password.getText().toString().trim();
        String confirmPasswordStr = confirmPassword.getText().toString().trim();

        if (!validateInputs(firstNameStr, lastNameStr, emailStr, phoneStr, gender, passwordStr, confirmPasswordStr)) {
            return;
        }

        if (userDataBase.checkUserExists(emailStr)) {
            Toast.makeText(getContext(), "Email already exists.", Toast.LENGTH_SHORT).show();
            return;
        }

        String hashedPassword = userDataBase.hashPassword(passwordStr);
        boolean result = userDataBase.insertAdmin(emailStr, hashedPassword, firstNameStr, lastNameStr, phoneStr, gender, true);

        if (result) {
            Toast.makeText(getContext(), "Admin added successfully.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getContext(), "Failed to add admin.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean validateInputs(String firstName, String lastName, String email, String phone, String gender, String password, String confirmPassword) {
        if (TextUtils.isEmpty(firstName) || firstName.length() < 3) {
            Toast.makeText(getContext(), "First name must be at least 3 characters.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(lastName) || lastName.length() < 3) {
            Toast.makeText(getContext(), "Last name must be at least 3 characters.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getContext(), "Enter a valid email address.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(phone) || phone.length() != 10 || !phone.startsWith("05")) {
            Toast.makeText(getContext(), "Phone number must be 10 digits and start with '05'.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (TextUtils.isEmpty(password) || password.length() < 8 || !password.matches(".*\\d.*") || !password.matches(".*[a-zA-Z].*")) {
            Toast.makeText(getContext(), "Password must be at least 8 characters and include at least one letter and one number.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(getContext(), "Passwords do not match.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}
