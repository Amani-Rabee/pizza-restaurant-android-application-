package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PizzaDetailsFragment extends Fragment {

    private static final String ARG_PIZZA = "pizza";
    private Pizza pizza;
    private ImageView favImage;
    private String userEmail;
    private UserDataBase dataBaseHelper;
    private int quantity = 2;
    private String selectedSize = "Medium";
    private Button smallSizeButton, mediumSizeButton, largeSizeButton;
    private TextView quantityTextView, pizzaPrice, catigory;
    private ImageView backButton;

    public static PizzaDetailsFragment newInstance(Pizza pizza) {
        PizzaDetailsFragment fragment = new PizzaDetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PIZZA, pizza);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            pizza = (Pizza) getArguments().getSerializable(ARG_PIZZA);
        }
    }

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pizza_details, container, false);
        userEmail = getActivity().getIntent().getStringExtra("email");
        dataBaseHelper = new UserDataBase(getContext());

        // Initialize UI elements and set pizza details
        TextView pizzaName = view.findViewById(R.id.pizzaName);
        pizzaPrice = view.findViewById(R.id.pizzaPriceDetailed);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ImageView pizzaImage = view.findViewById(R.id.pizza_image_detailed);
        quantityTextView = view.findViewById(R.id.quantityDetailed);
        catigory = view.findViewById(R.id.category_detailed);
        pizzaName.setText(pizza.getType());
        catigory.setText(pizza.getCategory());
        updatePizzaPrice();

        // Set the toolbar title and color
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null) {
            Toolbar toolbar = activity.findViewById(R.id.toolbar);
            toolbar.setTitle(pizza.getType());
            toolbar.setBackgroundColor(Color.parseColor("#FFFFFF"));
            toolbar.setTitleTextColor(Color.parseColor("black"));
        }

        // Load pizza image dynamically based on the pizza type
        switch (pizza.getType()) {
            case "Margarita":
                pizzaImage.setImageResource(R.drawable.margarita);
                break;
            case "Neapolitan":
                pizzaImage.setImageResource(R.drawable.neapolitan);
                break;
            case "Hawaiian":
                pizzaImage.setImageResource(R.drawable.hawaiian);
                break;
            case "Pepperoni":
                pizzaImage.setImageResource(R.drawable.pepperoni);
                break;
            case "New York Style":
                pizzaImage.setImageResource(R.drawable.new_ynework_style);
                break;
            case "Calzone":
                pizzaImage.setImageResource(R.drawable.calzone);
                break;
            case "Tandoori Chicken Pizza":
                pizzaImage.setImageResource(R.drawable.tandoori_chicken_pizza);
                break;
            case "BBQ Chicken Pizza":
                pizzaImage.setImageResource(R.drawable.bbq_chicken_pizza);
                break;
            case "Seafood Pizza":
                pizzaImage.setImageResource(R.drawable.seafood_pizza);
                break;
            case "Vegetarian Pizza":
                pizzaImage.setImageResource(R.drawable.vegetarian_pizza);
                break;
            case "Buffalo Chicken Pizza":
                pizzaImage.setImageResource(R.drawable.buffalo_hicken_pizza);
                break;
            case "Mushroom Truffle Pizza":
                pizzaImage.setImageResource(R.drawable.mushroom_truffle_pizza);
                break;
            case "Pesto Chicken Pizza":
                pizzaImage.setImageResource(R.drawable.pesto_chicken_pizza);
                break;
            default:
                pizzaImage.setImageResource(R.drawable.pizza_logo);
                break;
        }

        // Handle favorite button click
        favImage = view.findViewById(R.id.favoriteButtonDetailed);
        if (pizza.isFavorite()) {
            favImage.setImageResource(R.drawable.favorite_fill); // Change to the filled favorite icon resource
        } else {
            favImage.setImageResource(R.drawable.favourite_not_fill); // Change to the not filled favorite icon resource
        }

        favImage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100);
                        pizza.setFavorite(!pizza.isFavorite());

                        // Update the favorite button icon
                        if (pizza.isFavorite()) {
                            favImage.setImageResource(R.drawable.favorite_fill); // Change to the filled favorite icon resource
                            dataBaseHelper.insertFavoritePizza(userEmail,pizza.getType());
                        } else {
                            favImage.setImageResource(R.drawable.favourite_not_fill); // Change to the not filled favorite icon resource

                        }

                        // Update the favorite status in the database
                        dataBaseHelper.updatePizzaFavoriteStatus(userEmail, pizza);;
                    }
                });
            }

        });



        // Handle quantity increase/decrease
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button increaseQuantityButton = view.findViewById(R.id.increaseQuantityDetailed);
        Button decreaseQuantityButton = view.findViewById(R.id.decreaseQuantityDetailed);

        increaseQuantityButton.setOnClickListener(v -> {
            quantity++;
            quantityTextView.setText(String.valueOf(quantity));
        });

        decreaseQuantityButton.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                quantityTextView.setText(String.valueOf(quantity));
            }
        });

        // Handle size selection
        smallSizeButton = view.findViewById(R.id.smallSizeButton);
        mediumSizeButton = view.findViewById(R.id.mediumSizeButton);
        largeSizeButton = view.findViewById(R.id.largeSizeButton);

        smallSizeButton.setOnClickListener(v -> selectSize("Small"));
        mediumSizeButton.setOnClickListener(v -> selectSize("Medium"));
        largeSizeButton.setOnClickListener(v -> selectSize("Large"));

        // Handle order button click

        Button orderButton = view.findViewById(R.id.makeOrderDetailed);
        orderButton.setOnClickListener(v -> {
            String orderDetails = "Pizza: " + pizza.getType() + "\n" +
                    "Size: " + selectedSize + "\n" +
                    "Quantity: " + quantity + "\n" +
                    "Total Price: $" + calculateTotalPrice();

            // Show order details in a dialog
            new AlertDialog.Builder(getContext())
                    .setTitle("Order Confirmation")
                    .setMessage(orderDetails)
                    .setPositiveButton("Confirm", (dialog, which) -> {
                        // Insert the order into the database
                        dataBaseHelper.insertOrder(userEmail, pizza.getType(), selectedSize, quantity, calculateTotalPrice());
                        Toast.makeText(getContext(), "Order placed successfully", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Handle back button click
        backButton = view.findViewById(R.id.backButtonDetailed);
        backButton.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }

    private void selectSize(String size) {
        selectedSize = size;
        smallSizeButton.setBackgroundResource(size.equals("Small") ? R.drawable.selected_circle_button : R.drawable.circle_button );
        mediumSizeButton.setBackgroundResource(size.equals("Medium") ? R.drawable.selected_circle_button : R.drawable.circle_button);
        largeSizeButton.setBackgroundResource(size.equals("Large") ? R.drawable.selected_circle_button : R.drawable.circle_button);
        updatePizzaPrice();
    }

    private void updatePizzaPrice() {
        double price = pizza.getPrice(); // Default price for medium size
        if (selectedSize.equals("Small")) {
            price -= 2.00; // Example price adjustment for small size
        } else if (selectedSize.equals("Large")) {
            price += 2.00; // Example price adjustment for large size
        }
        pizzaPrice.setText(String.format("$%.2f", price));
    }
    public void updatePizzaDetails(Pizza pizza) {
        this.pizza = pizza; // Update the pizza object

        // Update the UI elements with the new pizza details
        TextView pizzaName = getView().findViewById(R.id.pizzaName);
        pizzaName.setText(pizza.getType());

        updatePizzaPrice(); // Update the price based on the new pizza object

        // Update the favorite button icon
        if (pizza.isFavorite()) {
            favImage.setImageResource(R.drawable.favorite_fill); // Change to the filled favorite icon resource
        } else {
            favImage.setImageResource(R.drawable.favourite_not_fill); // Change to the not filled favorite icon resource
        }

    }


    private double calculateTotalPrice() {
        double price = pizza.getPrice(); // Default price for medium size
        if (selectedSize.equals("Small")) {
            price -= 2.00; // Example price adjustment for small size
        } else if (selectedSize.equals("Large")) {
            price += 2.00; // Example price adjustment for large size
        }
        return price * quantity;
    }
}
