package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;


public class UserSignupLoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login_signup);

        // Set up the animation for the logo
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ImageView logoImageView = findViewById(R.id.logoImageView);
        Animation rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        logoImageView.startAnimation(rotateAnimation);

        // Set up the sign-up button
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button signUpButton = findViewById(R.id.signUpButton);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signUpIntent = new Intent(UserSignupLoginActivity.this, UserSignUpActivity.class);
                startActivity(signUpIntent);
            }
        });

        // Set up the log-in button
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button logInButton = findViewById(R.id.logInButton);
        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logInIntent = new Intent(UserSignupLoginActivity.this, UserLogInActivity.class);
                startActivity(logInIntent);
            }
        });
    }
}