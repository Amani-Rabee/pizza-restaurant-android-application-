package com.birzeit.androidproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class UserSignUpActivity extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, emailEditText, phoneNumberEditText,
            passwordEditText, confirmPasswordEditText;
    private Spinner genderSpinner;
    private Button signUpButton;
    private UserDataBase userDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_sign_up);

        // Initialize views
        firstNameEditText = findViewById(R.id.firstName);
        lastNameEditText = findViewById(R.id.lastName);
        emailEditText = findViewById(R.id.email);
        phoneNumberEditText = findViewById(R.id.phoneNumber);
        genderSpinner = findViewById(R.id.genderSpinner);
        passwordEditText = findViewById(R.id.password);
        confirmPasswordEditText = findViewById(R.id.confirmPassword);
        signUpButton = findViewById(R.id.signUpButton);
        ImageView back = findViewById(R.id.back);

        // Set up gender spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.gender_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(adapter);

        // Initialize UserDataBase
        userDataBase = new UserDataBase(this);

        back.setOnClickListener(v -> {
            Intent intent = new Intent(UserSignUpActivity.this, UserSignupLoginActivity.class);
            UserSignUpActivity.this.startActivity(intent);
            finish();
        });

        // Set onClickListener for the sign-up button
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });
    }

    private void signUp() {
        // Retrieve user inputs from EditText fields
        String firstName = firstNameEditText.getText().toString().trim();
        String lastName = lastNameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phoneNumber = phoneNumberEditText.getText().toString().trim();
        String gender = genderSpinner.getSelectedItem().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();

        // Validate inputs
        if (firstName.length() < 3) {
            firstNameEditText.setError("First name must be at least 3 characters");
            return;
        }

        if (lastName.length() < 3) {
            lastNameEditText.setError("Last name must be at least 3 characters");
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.setError("Enter a valid email address");
            return;
        }

        if (!Patterns.PHONE.matcher(phoneNumber).matches() || phoneNumber.length() != 10 || !phoneNumber.startsWith("05")) {
            phoneNumberEditText.setError("Enter a valid phone number starting with '05'");
            return;
        }

        if (password.length() < 8 || !password.matches(".*[a-zA-Z].*") || !password.matches(".*\\d.*")) {
            passwordEditText.setError("Password must be at least 8 characters and include both letters and numbers");
            return;
        }

        if (!password.equals(confirmPassword)) {
            confirmPasswordEditText.setError("Passwords do not match");
            return;
        }

        String hashedPassword = hashPassword(password);
        if (hashedPassword == null) {
            Toast.makeText(this, "Error hashing password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the email already exists in the database
        if (userDataBase.checkUserExists(email)) {
            emailEditText.setError("Email already exists");
            return;
        }

        // If all validations pass, register the user
        userDataBase.insertUser(email, hashedPassword, firstName, lastName, phoneNumber, gender,false);
        List<Pizza> initialPizzas = MainActivity.pizzaTypes;
        userDataBase.insertPizzasForUser(email, initialPizzas);
        for (Pizza pizza : initialPizzas) {
            long pizzaId = pizza.getId();

            userDataBase.insertPizzaSize(pizzaId, "small", pizza.getPrice(), 2);
            userDataBase.insertPizzaSize(pizzaId, "medium", pizza.getPrice(), 2);
            userDataBase.insertPizzaSize(pizzaId, "large", pizza.getPrice(), 2);
        }
        // Redirect to login page after successful registration
        Intent intent = new Intent(UserSignUpActivity.this, UserLogInActivity.class);
        startActivity(intent);
        finish();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());

            // Convert the byte array to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedPassword) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}