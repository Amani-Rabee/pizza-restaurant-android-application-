package com.birzeit.androidproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    private ViewFlipper viewFlipper;
    private LinearLayout indicatorLayout;
    private int[] images = {R.drawable.home1, R.drawable.home2, R.drawable.home3, R.drawable.home4};
    private ImageView[] dots;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_home, container, false);

        viewFlipper = view.findViewById(R.id.viewFlipper);
        indicatorLayout = view.findViewById(R.id.indicatorLayout);

        for (int image : images) {
            flipperImages(image);
        }

        addIndicators();
        return view;
    }

    public void flipperImages(int image) {
        ImageView imageView = new ImageView(getContext());
        imageView.setBackgroundResource(image);
        viewFlipper.addView(imageView);
        viewFlipper.setFlipInterval(3000); // 3 seconds
        viewFlipper.setAutoStart(true);
        // Animation
        viewFlipper.setInAnimation(getContext(), android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(getContext(), android.R.anim.slide_out_right);
    }

    public void addIndicators() {
        dots = new ImageView[images.length];
        for (int i = 0; i < images.length; i++) {
            dots[i] = new ImageView(getContext());
            dots[i].setImageDrawable(getResources().getDrawable(R.drawable.indicator_unselected));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );

            params.setMargins(8, 0, 8, 0);
            indicatorLayout.addView(dots[i], params);
        }

        // Set the first indicator as selected
        dots[0].setImageDrawable(getResources().getDrawable(R.drawable.indicator_selected));

        // Set a listener to handle indicator selection
        viewFlipper.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int displayedChild = viewFlipper.getDisplayedChild();
                for (int i = 0; i < images.length; i++) {
                    if (i == displayedChild) {
                        dots[i].setImageDrawable(getResources().getDrawable(R.drawable.indicator_selected));
                    } else {
                        dots[i].setImageDrawable(getResources().getDrawable(R.drawable.indicator_unselected));
                    }
                }
                return false;
            }
        });

        // Add a flip listener to update indicators on flip completion
        viewFlipper.setInAnimation(getContext(), android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(getContext(), android.R.anim.slide_out_right);
        viewFlipper.getInAnimation().setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                int displayedChild = viewFlipper.getDisplayedChild();
                for (int i = 0; i < images.length; i++) {
                    dots[i].setImageDrawable(getResources().getDrawable(i == displayedChild ? R.drawable.indicator_selected : R.drawable.indicator_unselected));
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
    }



}
