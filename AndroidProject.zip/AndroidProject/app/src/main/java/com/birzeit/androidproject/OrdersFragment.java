package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OrdersFragment extends Fragment {

    private UserDataBase userDataBase;
    private String userEmail;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_orders, container, false);

            userEmail = getActivity().getIntent().getStringExtra("email");
            userDataBase = new UserDataBase(getContext());

            @SuppressLint({"MissingInflatedId", "LocalSuppress"}) RecyclerView recyclerView = view.findViewById(R.id.recyclerViewOrders);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

            List<Order> orderHistory = userDataBase.getOrderHistory(userEmail);
            OrderAdapter adapter = new OrderAdapter(orderHistory, getContext());
            recyclerView.setAdapter(adapter);
            LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_animation_fall_down);
            recyclerView.setLayoutAnimation(animation);
            return view;
        }



    private void navigateToOrderDetails(Order order) {
        OrderDetailsFragment orderDetailsFragment = new OrderDetailsFragment();
        Bundle args = new Bundle();
        args.putString("pizzaType", order.getPizzaType());
        args.putString("pizzaSize", order.getPizzaSize());
        args.putInt("quantity", order.getQuantity());
        args.putDouble("totalPrice", order.getTotalPrice());
        args.putString("orderDate", order.getOrderDate());
        orderDetailsFragment.setArguments(args);

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, orderDetailsFragment);
        transaction.addToBackStack(null);  // Optional: Add fragment to back stack
        transaction.commit();
    }

}
