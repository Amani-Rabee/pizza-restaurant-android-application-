package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;
import java.util.List;

public class SpecialOffersFragment extends Fragment {

    private RecyclerView recyclerView;
    private SpecialOfferAdapter adapter;
    private List<SpecialOffer> specialOffers;

    private UserDataBase userDataBase;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userDataBase = new UserDataBase(getContext());
        specialOffers = new ArrayList<>();
        // Fetch special offers from the database
        fetchSpecialOffers();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_special_offers, container, false);
        recyclerView = view.findViewById(R.id.recyclerviewSpecialOffers);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new SpecialOfferAdapter(getContext(), specialOffers);
        recyclerView.setAdapter(adapter);
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_animation_fall_down);
        recyclerView.setLayoutAnimation(animation);
        return view;
    }
    @SuppressLint("Range")
    private void fetchSpecialOffers() {
        Cursor cursor = userDataBase.getSpecialOffers();
        if (cursor.moveToFirst()) {
            do {
               long pizzaId = cursor.getLong(cursor.getColumnIndex("pizza_id"));
                String size = cursor.getString(cursor.getColumnIndex("size"));
                double totalPrice = cursor.getDouble(cursor.getColumnIndex("total_price"));
                String startDate = cursor.getString(cursor.getColumnIndex("start_date"));
                String endDate = cursor.getString(cursor.getColumnIndex("end_date"));

                // Get pizza name from pizza_id using another method in UserDataBase
                String pizzaName =MainActivity.pizzaTypes.get((int) pizzaId).getType();

                SpecialOffer specialOffer = new SpecialOffer(pizzaName, size, MainActivity.pizzaTypes.get((int) pizzaId).getPrice(), MainActivity.pizzaTypes.get((int) pizzaId).getPrice()*(1-totalPrice), R.drawable.pizza_logo);
                specialOffer.setStartDate(startDate);
                specialOffer.setEndDate(endDate);

                specialOffers.add(specialOffer);

            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
