package com.birzeit.androidproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PizzaMenuFragment extends Fragment {

    private ArrayList<Pizza> pizzaList;
    private RecyclerView recyclerView;
    private PizzaAdapter pizzaAdapter;
    private String userEmail;
    private UserDataBase dataBaseHelper;
    private Button selectedButton;
    private String currentCategory = "All";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pizza_menu, container, false);

        userEmail = getActivity().getIntent().getStringExtra("email");
        dataBaseHelper = new UserDataBase(getContext());
        pizzaList = (ArrayList<Pizza>) dataBaseHelper.getPizzasForUser(userEmail);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        pizzaAdapter = new PizzaAdapter(pizzaList, getContext(), this::showPizzaDetails, this::addToFavorites, this::placeOrder);
        recyclerView.setAdapter(pizzaAdapter);
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_animation_fall_down);
        recyclerView.setLayoutAnimation(animation);

        // Initialize search and filter components
        SearchView searchView = view.findViewById(R.id.searchView);
        ImageButton filterButton = view.findViewById(R.id.filterButton);
        Button filterAll = view.findViewById(R.id.filter_all);
        Button filterVeggies = view.findViewById(R.id.filter_veggies);
        Button filterBeef = view.findViewById(R.id.filter_beef);
        Button filterChicken = view.findViewById(R.id.filter_chicken);

        // Set default selected button (for category filter)
        selectedButton = filterAll;
        selectedButton.setBackground(ContextCompat.getDrawable(getContext(), R.drawable.button_background));

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterPizzas(query, currentCategory);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterPizzas(newText, currentCategory);
                return false;
            }
        });

        // Filter button functionality (show AlertDialog for filter options)
        filterButton.setOnClickListener(v -> showFilterOptionsDialog());

        // Category filter buttons functionality
        filterAll.setOnClickListener(v -> {
            currentCategory = "All";
            filterPizzas(searchView.getQuery().toString(), currentCategory);
            changeButtonBackground(filterAll);
        });
        filterVeggies.setOnClickListener(v -> {
            currentCategory = "Veggies";
            filterPizzas(searchView.getQuery().toString(), currentCategory);
            changeButtonBackground(filterVeggies);
        });
        filterBeef.setOnClickListener(v -> {
            currentCategory = "Beef";
            filterPizzas(searchView.getQuery().toString(), currentCategory);
            changeButtonBackground(filterBeef);
        });
        filterChicken.setOnClickListener(v -> {
            currentCategory = "Chicken";
            filterPizzas(searchView.getQuery().toString(), currentCategory);
            changeButtonBackground(filterChicken);
        });

        return view;
    }
    private void addToFavorites(Pizza pizza) {
        // Toggle the favorite status
        pizza.setFavorite(!pizza.isFavorite());
        if (pizza.isFavorite())
            dataBaseHelper.insertFavoritePizza(userEmail, pizza.getType());
        // Notify the adapter of the data change
        pizzaAdapter.notifyDataSetChanged();

        // Update the favorite status in the database
        dataBaseHelper.updatePizzaFavoriteStatus(userEmail, pizza);

        // Check if the fragment is an instance of PizzaDetailsFragment before casting
        Fragment fragment = getParentFragmentManager().findFragmentById(R.id.fragment_container);
        if (fragment instanceof PizzaDetailsFragment) {
            PizzaDetailsFragment detailsFragment = (PizzaDetailsFragment) fragment;
            // Update the details fragment with the new pizza data
            detailsFragment.updatePizzaDetails(pizza);
        }
    }
    private void filterPizzas(String query, String category) {
        ArrayList<Pizza> filteredList = new ArrayList<>();

        // Check if the query is in price range format
        if (query.matches("\\d+(\\.\\d+)?-\\d+(\\.\\d+)?")) {
            // Query is in price range format
            String[] parts = query.split("-");
            double minPrice = Double.parseDouble(parts[0]);
            double maxPrice = Double.parseDouble(parts[1]);

            for (Pizza pizza : pizzaList) {
                boolean matchesCategory = category.equals("All") || pizza.getCategory().equalsIgnoreCase(category);
                boolean matchesPriceRange = pizza.getPrice() >= minPrice && pizza.getPrice() <= maxPrice;
                if (matchesCategory && matchesPriceRange) {
                    filteredList.add(pizza);
                }
            }
        } else {
            // Regular query string
            for (Pizza pizza : pizzaList) {
                boolean matchesCategory = category.equals("All") || pizza.getCategory().equalsIgnoreCase(category);
                boolean matchesQuery = pizza.getType().toLowerCase().contains(query.toLowerCase()) ||
                        String.valueOf(pizza.getPrice()).contains(query) ||
                        pizza.getSize().toLowerCase().contains(query.toLowerCase()) ||
                        pizza.getCategory().toLowerCase().contains(query.toLowerCase());
                if (matchesCategory && matchesQuery) {
                    filteredList.add(pizza);
                }
            }
        }

        pizzaAdapter.updateList(filteredList);
    }

    private void showFilterOptionsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Select Categories and Price Range to Filter");

        // Inflate the dialog view layout
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_filter_options, null);
        builder.setView(dialogView);

        // EditText fields for min and max price
        EditText etMinPrice = dialogView.findViewById(R.id.etMinPrice);
        EditText etMaxPrice = dialogView.findViewById(R.id.etMaxPrice);

        // Category selection
        String[] categoriesArray = {"All", "Veggies", "Beef", "Chicken"}; // Replace with your actual categories
        boolean[] checkedItems = {currentCategory.equals("All"), currentCategory.equals("Veggies"),
                currentCategory.equals("Beef"), currentCategory.equals("Chicken")};

        builder.setMultiChoiceItems(categoriesArray, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i, boolean isChecked) {
                if (isChecked) {
                    currentCategory = categoriesArray[i];
                } else {
                    currentCategory = "All"; // Reset to show all if "All" is unchecked
                }
            }
        });

        builder.setPositiveButton("Filter", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Get min and max price values from EditText fields
                String minPriceStr = etMinPrice.getText().toString().trim();
                String maxPriceStr = etMaxPrice.getText().toString().trim();

                double minPrice = TextUtils.isEmpty(minPriceStr) ? Double.MIN_VALUE : Double.parseDouble(minPriceStr);
                double maxPrice = TextUtils.isEmpty(maxPriceStr) ? Double.MAX_VALUE : Double.parseDouble(maxPriceStr);

                filterPizzas(minPrice+"-"+maxPrice, currentCategory); // Filter with price range and category
                changeButtonBackground(selectedButton); // Update button background
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.create().show();
    }
    private void changeButtonBackground(Button clickedButton) {
        if (selectedButton != null) {
            selectedButton.setBackground(ContextCompat.getDrawable(getContext(), R.drawable.edittext_border)); // Reset previous button drawable
        }
        clickedButton.setBackground(ContextCompat.getDrawable(getContext(), R.drawable.button_background)); // Set new button drawable
        selectedButton = clickedButton; // Update the selected button reference
    }
    private void showPizzaDetails(Pizza pizza) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        PizzaDetailsFragment detailsFragment = PizzaDetailsFragment.newInstance(pizza);
        transaction.replace(R.id.fragment_container, detailsFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    private void placeOrder(Pizza pizza) {
        // Code to place an order
    }
}
