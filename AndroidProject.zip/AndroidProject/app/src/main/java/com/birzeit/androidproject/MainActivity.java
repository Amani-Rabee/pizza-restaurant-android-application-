package com.birzeit.androidproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button get_started;
    public static List<Pizza> pizzaTypes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        get_started = findViewById(R.id.Start_Button);
        UserDataBase userDataBase = new UserDataBase(this);
        userDataBase.insertInitialAdmin();  // Call this method if you haven't initialized your admin before
        get_started.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectionAsyncTask connectionAsyncTask = new ConnectionAsyncTask(MainActivity.this);
                // Using the new URL for JSON data
                connectionAsyncTask.execute("https://mocki.io/v1/22d1ff2e-f13f-4d4e-8c03-da45efe2d886");
            }
        });
    }

    public void setButtonText(String text) {
        get_started.setText(text);
    }

    public void setProgress(boolean progress) {
        ProgressBar progressBar = findViewById(R.id.progressBar);
        if (progress) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    public void dataLoaded(List<Pizza> pizzas) {
        pizzaTypes = pizzas; // Save the loaded data
        System.out.println("Loaded Pizzas: " + pizzaTypes); // For debugging: to check the loaded data

        // Start the UserSignUpActivity only after the data is loaded
        Intent intent = new Intent(MainActivity.this, UserSignupLoginActivity.class);
        startActivity(intent);
        finish(); // Finish MainActivity to prevent returning to it
    }
}