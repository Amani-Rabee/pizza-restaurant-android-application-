package com.birzeit.androidproject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
public class PizzaJsonParser {
    public static List<Pizza> getObjectFromJson(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray jsonArray = jsonObject.getJSONArray("pizzas");

            ArrayList<Pizza> pizzaList = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject pizzaObject = jsonArray.getJSONObject(i);

                Pizza pizza = new Pizza();
                pizza.setType(pizzaObject.getString("type"));
                pizza.setPrice(pizzaObject.getDouble("price"));
                pizza.setSize(pizzaObject.getString("size"));
                pizza.setCategory(pizzaObject.getString("category"));
                pizza.setFavorite(pizzaObject.getBoolean("isFavorite"));
                pizza.setId(i);
                pizzaList.add(pizza);
            }
            return pizzaList;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }


}
