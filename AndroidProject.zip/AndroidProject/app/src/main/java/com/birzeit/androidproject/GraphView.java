package com.birzeit.androidproject;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;

import java.util.List;

public class GraphView extends View {

    private List<Pair<String, Integer>> dataPoints;
    private List<Pair<String, Double>> incomeDataPoints;
    private Paint ordersPaint;
    private Paint incomePaint;
    private Paint textPaint;

    public GraphView(Context context) {
        super(context);
        init();
    }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GraphView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        ordersPaint = new Paint();
        ordersPaint.setColor(Color.BLUE);
        ordersPaint.setStrokeWidth(10);

        incomePaint = new Paint();
        incomePaint.setColor(Color.GREEN);
        incomePaint.setStrokeWidth(10);

        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(30);
    }

    public void setDataPoints(List<Pair<String, Integer>> dataPoints) {
        this.dataPoints = dataPoints;
        invalidate();
    }

    public void setIncomeDataPoints(List<Pair<String, Double>> incomeDataPoints) {
        this.incomeDataPoints = incomeDataPoints;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float startX = 100;
        float startY = getHeight() - 100;
        float stepX = (getWidth() - 200) / (dataPoints != null ? dataPoints.size() : 1);

        if (dataPoints != null && !dataPoints.isEmpty()) {
            for (int i = 0; i < dataPoints.size(); i++) {
                String label = dataPoints.get(i).first;
                int value = dataPoints.get(i).second;

                float endX = startX + (i * stepX);
                float endY = startY - (value * 10); // Scale the value for display

                if (i > 0) {
                    canvas.drawLine(startX + ((i - 1) * stepX), startY - (dataPoints.get(i - 1).second * 10), endX, endY, ordersPaint);
                }
                canvas.drawText(label, endX, startY + 30, textPaint);
            }
        }

        startY = getHeight() - 200; // Adjust starting point for income graph
        if (incomeDataPoints != null && !incomeDataPoints.isEmpty()) {
            for (int i = 0; i < incomeDataPoints.size(); i++) {
                String label = incomeDataPoints.get(i).first;
                Double value = incomeDataPoints.get(i).second;

                float endX = startX + (i * stepX);
                float endY = (float) (startY - value * 0.1); // Scale the value for display

                if (i > 0) {
                    canvas.drawLine(startX + ((i - 1) * stepX), (float) (startY - ( incomeDataPoints.get(i - 1).second * 0.1)), endX, endY, incomePaint);
                }
                canvas.drawText(label, endX, startY + 30, textPaint);
            }
        }
    }
}
