package com.birzeit.androidproject;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AllOrdersAdapter extends RecyclerView.Adapter<AllOrdersAdapter.AllOrdersViewHolder> {

    private List<Order> orderList;
    private Context context;
    private UserDataBase userDataBase;

    public AllOrdersAdapter(List<Order> orderList, Context context) {
        this.orderList = orderList;
        this.context = context;
        this.userDataBase = new UserDataBase(context);
    }

    @NonNull
    @Override
    public AllOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.all_orders_item, parent, false);
        return new AllOrdersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AllOrdersViewHolder holder, int position) {
        Order order = orderList.get(position);
        holder.bind(order);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class AllOrdersViewHolder extends RecyclerView.ViewHolder {

        TextView customerNameTextView;
        TextView pizzaNameTextView;
        TextView pizzaSizeTextView;
        TextView pizzaQuantityTextView;
        TextView orderDateTextView;
        TextView orderedPizzaPriceTextView;
        ImageView pizzaImageView;

        public AllOrdersViewHolder(@NonNull View itemView) {
            super(itemView);
            customerNameTextView = itemView.findViewById(R.id.customer_name_order);
            pizzaNameTextView = itemView.findViewById(R.id.pizza_name_order);
            pizzaSizeTextView = itemView.findViewById(R.id.pizza_size_order);
            pizzaQuantityTextView = itemView.findViewById(R.id.pizza_quantity_order);
            orderDateTextView = itemView.findViewById(R.id.order_date);
            orderedPizzaPriceTextView = itemView.findViewById(R.id.ordered_pizza_price);
            pizzaImageView = itemView.findViewById(R.id.pizza_image_order);
        }

        public void bind(Order order) {
            // Fetch customer details from the database based on email
            Cursor cursor = userDataBase.getUser(order.getEmail());
            if (cursor.moveToFirst()) {
                String firstName = cursor.getString(cursor.getColumnIndexOrThrow("first_name"));
                String lastName = cursor.getString(cursor.getColumnIndexOrThrow("last_name"));
                String customerName = firstName + " " + lastName;
                customerNameTextView.setText(customerName);
            }
            cursor.close();

            pizzaNameTextView.setText(order.getPizzaType());
            pizzaSizeTextView.setText("Size: " + order.getPizzaSize());
            pizzaQuantityTextView.setText("Quantity: " + order.getQuantity());
            orderDateTextView.setText(order.getOrderDate());
            orderedPizzaPriceTextView.setText(String.format("$%.2f", order.getTotalPrice()));

            switch (order.getPizzaType()) {
                case "Margarita":
                    pizzaImageView.setImageResource(R.drawable.margarita);
                    break;
                case "Neapolitan":
                    pizzaImageView.setImageResource(R.drawable.neapolitan);
                    break;
                case "Hawaiian":
                    pizzaImageView.setImageResource(R.drawable.hawaiian);
                    break;
                case "Pepperoni":
                    pizzaImageView.setImageResource(R.drawable.pepperoni);
                    break;
                case "New York Style":
                    pizzaImageView.setImageResource(R.drawable.new_ynework_style);
                    break;
                case "Calzone":
                    pizzaImageView.setImageResource(R.drawable.calzone);
                    break;
                case "Tandoori Chicken Pizza":
                    pizzaImageView.setImageResource(R.drawable.tandoori_chicken_pizza);
                    break;
                case "BBQ Chicken Pizza":
                    pizzaImageView.setImageResource(R.drawable.bbq_chicken_pizza);
                    break;
                case "Seafood Pizza":
                    pizzaImageView.setImageResource(R.drawable.seafood_pizza);
                    break;
                case "Vegetarian Pizza":
                    pizzaImageView.setImageResource(R.drawable.vegetarian_pizza);
                    break;
                case "Buffalo Chicken Pizza":
                    pizzaImageView.setImageResource(R.drawable.buffalo_hicken_pizza);
                    break;
                case "Mushroom Truffle Pizza":
                    pizzaImageView.setImageResource(R.drawable.mushroom_truffle_pizza);
                    break;
                case "Pesto Chicken Pizza":
                    pizzaImageView.setImageResource(R.drawable.pesto_chicken_pizza);
                    break;
                default:
                    pizzaImageView.setImageResource(R.drawable.pizza_logo);
                    break;
            }
        }
    }
}
