package com.birzeit.androidproject;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Pair;
import android.widget.Toast;
import java.util.List;

public class ConnectionAsyncTask extends AsyncTask<String, Void, Pair<String, List<Pizza>>> {
    Activity activity;


    public ConnectionAsyncTask(Activity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        ((MainActivity) activity).setButtonText("Starting..");
        super.onPreExecute();
        ((MainActivity) activity).setProgress(true);
    }

    @Override
    protected Pair<String, List<Pizza>> doInBackground(String... params) {
        try {
            String data = HttpManager.getData(params[0]);
            List<Pizza> pizza = PizzaJsonParser.getObjectFromJson(data);
            return new Pair<>(null, pizza);
        } catch (Exception e) {
            String errorMessage = "Error: " + e.getMessage();
            return new Pair<>(errorMessage, null);  // Return error message
        }
    }

    @Override
    protected void onPostExecute(Pair<String, List<Pizza>> result) {
        super.onPostExecute(result);
        ((MainActivity) activity).setProgress(false);

        if (result.second != null) {
            // Data loaded successfully
            ((MainActivity) activity).setButtonText("STARTED");
            ((MainActivity) activity).dataLoaded(result.second);

        } else {
            // Show error message if data loading failed
            ((MainActivity) activity).setButtonText("Get Started");
            Toast.makeText(activity, "Loading error! please try again", Toast.LENGTH_LONG).show();

        }
    }
}
