package com.birzeit.androidproject;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class ReportFragment extends Fragment {

    private Button  buttonCalculateSpecific;
    private TextView textViewTotalIncome, textViewTotalOrders, textViewSpecificOrders, textViewSpecificIncome;
    private Spinner spinnerPizzaType;

    private UserDataBase userDataBase;
    private String selectedPizzaType;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_report, container, false);

        buttonCalculateSpecific = rootView.findViewById(R.id.button_calculate_specific);
        textViewTotalIncome = rootView.findViewById(R.id.text_view_total_income);
        textViewTotalOrders = rootView.findViewById(R.id.text_view_total_orders);
        textViewSpecificOrders = rootView.findViewById(R.id.text_view_specific_orders);
        textViewSpecificIncome = rootView.findViewById(R.id.text_view_specific_income);
        spinnerPizzaType = rootView.findViewById(R.id.spinner_pizza_type);

        userDataBase = new UserDataBase(getActivity());

        loadPizzaTypes();
        calculateTotalIncomeAndOrders();


        buttonCalculateSpecific.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateSpecificPizzaTypeOrdersAndIncome();
            }
        });

        spinnerPizzaType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPizzaType = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        return rootView;
    }

    private void loadPizzaTypes() {
        List<Pizza> pizzas = MainActivity.pizzaTypes;
        List<String> pizzaTypes = new ArrayList<>();
        for (int i=0; i<pizzas.size();i++)
        {
            pizzaTypes.add(pizzas.get(i).getType());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, pizzaTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPizzaType.setAdapter(adapter);
    }

    private void calculateTotalIncomeAndOrders() {
        double totalIncome = userDataBase.getTotalIncomeForAllPizzaTypes();
        int totalOrders = userDataBase.getOrdersCountForAllPizzaTypes();

        textViewTotalIncome.setText("Total Income: \n" + String.format("%.2f", totalIncome));
        textViewTotalOrders.setText("Total Orders: \n" + totalOrders);

        textViewTotalIncome.setVisibility(View.VISIBLE);
        textViewTotalOrders.setVisibility(View.VISIBLE);
    }

    private void calculateSpecificPizzaTypeOrdersAndIncome() {
        if (selectedPizzaType != null) {
            int specificOrdersCount = userDataBase.getOrdersCountForSpecificPizzaType(selectedPizzaType);
            double specificIncome = userDataBase.getTotalIncomeForSpecificPizzaType(selectedPizzaType);

            textViewSpecificOrders.setText("Orders for " + selectedPizzaType + ": " + specificOrdersCount);
            textViewSpecificIncome.setText("Income for " + selectedPizzaType + ": " + String.format("%.2f", specificIncome));

            textViewSpecificOrders.setVisibility(View.VISIBLE);
            textViewSpecificIncome.setVisibility(View.VISIBLE);
        }
    }
}
