package com.birzeit.androidproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class SpecialOfferAdapter extends RecyclerView.Adapter<SpecialOfferAdapter.SpecialOfferViewHolder> {

    private Context context;
    private List<SpecialOffer> specialOffers;
    private Handler handler;

    public SpecialOfferAdapter(Context context, List<SpecialOffer> specialOffers) {
        this.context = context;
        this.specialOffers = specialOffers;
        this.handler = new Handler(Looper.getMainLooper());
    }

    @NonNull
    @Override
    public SpecialOfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_special_offers, parent, false);
        return new SpecialOfferViewHolder(view);
    }



        @Override
        public void onBindViewHolder(@NonNull SpecialOfferViewHolder holder, int position) {
            SpecialOffer specialOffer = specialOffers.get(position);

            // Set pizza image based on pizza name
            holder.imageViewPizza.setImageResource(getPizzaImageResource(specialOffer.getPizzaName()));
            holder.textViewPizzaName.setText(specialOffer.getPizzaName());
            holder.textViewSize.setText(specialOffer.getPizzaCategory()); // You can set the category here if needed
            holder.textViewOriginalPrice.setText(String.format("$ %.2f", specialOffer.getOriginalPrice()));
            holder.textViewOfferPrice.setText(String.format("$ %.2f", specialOffer.getOfferPrice()));
            holder.textViewStartDate.setText("Start Date: " + specialOffer.getStartDate());
            holder.textViewEndDate.setText("End Date: " + specialOffer.getEndDate());

            // Calculate and display countdown timer
            updateCountdown(holder, specialOffer.getEndDate());
            holder.textViewOriginalPrice.setPaintFlags(holder.textViewOriginalPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            // Handle order button click
            holder.offerOrderButton.setOnClickListener(v -> {
                // Check if offer is expired
                if (isOfferExpired(specialOffer)) {

                    Toast.makeText(context, "This offer has expired.", Toast.LENGTH_SHORT).show();
                } else {
                    // Open OfferDetailsFragment
                    OfferDetailsFragment offerDetailsFragment = OfferDetailsFragment.newInstance(specialOffer);
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, offerDetailsFragment)
                            .addToBackStack(null)
                            .commit();
                }
            });
        }

    // Method to check if the offer is expired
    private boolean isOfferExpired(SpecialOffer specialOffer) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            Date endDateObj = dateFormat.parse(specialOffer.getEndDate());
            long endTimeMillis = endDateObj.getTime();
            long currentTimeMillis = System.currentTimeMillis();
            return currentTimeMillis > endTimeMillis;
        } catch (ParseException e) {
            e.printStackTrace();
            return true; // If parsing fails, assume offer is expired
        }
    }

    private void updateCountdown(final SpecialOfferViewHolder holder, String endDate) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            final Date endDateObj = dateFormat.parse(endDate);
            final long endTimeMillis = endDateObj.getTime();

            // Runnable to update countdown every second
            final Runnable countdownRunnable = new Runnable() {
                @Override
                public void run() {
                    long currentTimeMillis = System.currentTimeMillis();
                    long timeDiffMillis = endTimeMillis - currentTimeMillis;

                    if (timeDiffMillis > 0) {
                        // Calculate days, hours, minutes, and seconds
                        long days = TimeUnit.MILLISECONDS.toDays(timeDiffMillis);
                        long hours = TimeUnit.MILLISECONDS.toHours(timeDiffMillis) % 24;
                        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeDiffMillis) % 60;
                        long seconds = TimeUnit.MILLISECONDS.toSeconds(timeDiffMillis) % 60;

                        // Update countdown text
                        String countdownText = String.format(Locale.getDefault(), "Expires in %d: %02d: %02d: %02d", days, hours, minutes, seconds);
                        holder.textViewCountdown.setText(countdownText);

                        // Schedule next update in 1 second
                        handler.postDelayed(this, 1000);
                    } else {
                        holder.textViewCountdown.setText("Offer expired");
                    }
                }
            };

            // Initial call to start countdown
            countdownRunnable.run();

        } catch (ParseException e) {
            e.printStackTrace();
            holder.textViewCountdown.setText("Date parsing error");
        }
    }

    @Override
    public int getItemCount() {
        return specialOffers.size();
    }

    // Method to get pizza image resource based on pizza name
    private int getPizzaImageResource(String pizzaName) {
        switch (pizzaName) {
            case "Margarita":
                return R.drawable.margarita;
            case "Neapolitan":
                return R.drawable.neapolitan;
            case "Hawaiian":
                return R.drawable.hawaiian;
            case "Pepperoni":
                return R.drawable.pepperoni;
            case "New York Style":
                return R.drawable.new_ynework_style;
            case "Calzone":
                return R.drawable.calzone;
            case "Tandoori Chicken Pizza":
                return R.drawable.tandoori_chicken_pizza;
            case "BBQ Chicken Pizza":
                return R.drawable.bbq_chicken_pizza;
            case "Seafood Pizza":
                return R.drawable.seafood_pizza;
            case "Vegetarian Pizza":
                return R.drawable.vegetarian_pizza;
            case "Buffalo Chicken Pizza":
                return R.drawable.buffalo_hicken_pizza;
            case "Mushroom Truffle Pizza":
                return R.drawable.mushroom_truffle_pizza;
            case "Pesto Chicken Pizza":
                return R.drawable.pesto_chicken_pizza;
            default:
                return R.drawable.pizza_logo;
        }
    }

    public static class SpecialOfferViewHolder extends RecyclerView.ViewHolder {

        ImageView imageViewPizza;
        TextView textViewPizzaName;
        TextView textViewSize;
        TextView textViewOriginalPrice;
        TextView textViewOfferPrice;
        TextView textViewStartDate;
        TextView textViewEndDate;
        TextView textViewCountdown; // Add this line for countdown
        ImageButton offerOrderButton;

        @SuppressLint("WrongViewCast")
        public SpecialOfferViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewPizza = itemView.findViewById(R.id.imageViewPizza);
            textViewPizzaName = itemView.findViewById(R.id.textViewPizzaName);
            textViewSize = itemView.findViewById(R.id.textViewSize);
            textViewOriginalPrice = itemView.findViewById(R.id.textViewOriginalPrice);
            textViewOfferPrice = itemView.findViewById(R.id.textViewOfferPrice);
            textViewStartDate = itemView.findViewById(R.id.textViewStartDate);
            textViewEndDate = itemView.findViewById(R.id.textViewEndDate);
            textViewCountdown = itemView.findViewById(R.id.textViewCountdown); // Initialize countdown TextView
            offerOrderButton = itemView.findViewById(R.id.oder_offer_button);
        }
    }
}
