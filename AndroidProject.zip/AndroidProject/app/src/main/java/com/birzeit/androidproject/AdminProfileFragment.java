package com.birzeit.androidproject;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AdminProfileFragment extends Fragment {

    private TextView firstNameDisplay, lastNameDisplay, phoneNumberDisplay, passwordDisplay;
    private EditText firstNameEdit, lastNameEdit, phoneNumberEdit, passwordEdit;
    private ImageView editIconFirstName, editIconLastName, editIconPhoneNumber, editIconPassword;
    private Button updateButton;
    private UserDataBase userDataBase;
    private String userEmail; // Admin's email initialized in the database

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_profile, container, false);

        userDataBase = new UserDataBase(getActivity());
        initializeUI(view);

        // Get email from arguments
        Bundle args = getArguments();
        if (args != null) {
            userEmail = args.getString("userEmail");
        }

        loadAdminData();
        setupEditIcons();

        return view;
    }

    private void initializeUI(View view) {
        firstNameDisplay = view.findViewById(R.id.firstNameDisplay);
        lastNameDisplay = view.findViewById(R.id.lastNameDisplay);
        phoneNumberDisplay = view.findViewById(R.id.phoneNumberDisplay);
        passwordDisplay = view.findViewById(R.id.passwordDisplay);

        firstNameEdit = view.findViewById(R.id.firstNameEdit);
        lastNameEdit = view.findViewById(R.id.lastNameEdit);
        phoneNumberEdit = view.findViewById(R.id.phoneNumberEdit);
        passwordEdit = view.findViewById(R.id.passwordEdit);

        editIconFirstName = view.findViewById(R.id.editIconFirstName);
        editIconLastName = view.findViewById(R.id.editIconLastName);
        editIconPhoneNumber = view.findViewById(R.id.editIconPhoneNumber);
        editIconPassword = view.findViewById(R.id.editIconPassword);

        updateButton = view.findViewById(R.id.updateButton);
        updateButton.setOnClickListener(v -> updateAdminData());
    }

    private void setupEditIcons() {
        editIconFirstName.setOnClickListener(v -> toggleEdit(firstNameDisplay, firstNameEdit));
        editIconLastName.setOnClickListener(v -> toggleEdit(lastNameDisplay, lastNameEdit));
        editIconPhoneNumber.setOnClickListener(v -> toggleEdit(phoneNumberDisplay, phoneNumberEdit));
        editIconPassword.setOnClickListener(v -> toggleEdit(passwordDisplay, passwordEdit));
    }
    private void toggleEdit(TextView displayView, EditText editView) {
        if (editView.getVisibility() == View.INVISIBLE) {
            // Switch to edit mode
            editView.setText(displayView.getText());
            editView.setVisibility(View.VISIBLE);
            displayView.setVisibility(View.GONE);
            editView.requestLayout(); // Force the layout to reapply constraints
        } else {
            // Apply changes and switch back to display mode
            displayView.setText(editView.getText());
            editView.setVisibility(View.GONE);
            displayView.setVisibility(View.VISIBLE);
            editView.requestLayout(); // Force the layout to reapply constraints
        }
    }

    private void loadAdminData() {
        SQLiteDatabase db = userDataBase.getReadableDatabase();
        Cursor cursor = db.query("Users", new String[]{"first_name", "last_name", "phone_number", "password"}, "email = ?", new String[]{userEmail}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            firstNameDisplay.setText(cursor.getString(cursor.getColumnIndexOrThrow("first_name")));
            lastNameDisplay.setText(cursor.getString(cursor.getColumnIndexOrThrow("last_name")));
            phoneNumberDisplay.setText(cursor.getString(cursor.getColumnIndexOrThrow("phone_number")));
            // Do not load password for security reasons
            cursor.close();
        } else {
            Toast.makeText(getContext(), "Failed to load user data.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateAdminData() {
        String newFirstName = firstNameEdit.getText().toString().trim();
        String newLastName = lastNameEdit.getText().toString().trim();
        String newPhoneNumber = phoneNumberEdit.getText().toString().trim();
        String newPassword = passwordEdit.getText().toString().trim();

        // Validate inputs
        if (!validateInputs(newFirstName, newLastName, newPhoneNumber, newPassword)) {
            return;
        }

        SQLiteDatabase db = userDataBase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("first_name", newFirstName);
        values.put("last_name", newLastName);
        values.put("phone_number", newPhoneNumber);
        values.put("password", userDataBase.hashPassword(newPassword));

        try {
            int rowsAffected = db.update("Users", values, "email=?", new String[]{userEmail});
            if (rowsAffected > 0) {
                Toast.makeText(getContext(), "Profile updated successfully!", Toast.LENGTH_SHORT).show();
                loadAdminData(); // Refresh UI with updated data
            } else {
                Toast.makeText(getContext(), "No changes were made.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getContext(), "Failed to update profile: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean validateInputs(String firstName, String lastName, String phoneNumber, String password) {
        if (firstName.length() < 3) {
            this.firstNameEdit.setError("First name must be at least 3 characters long.");
            return false;
        }
        if (lastName.length() < 3) {
            this.lastNameEdit.setError("Last name must be at least 3 characters long.");
            return false;
        }
        if (!phoneNumber.matches("05\\d{8}")) {
            this.phoneNumberEdit.setError("Phone number must be exactly 10 digits starting with '05'.");
            return false;
        }
        if (password.length() < 8 || !password.matches(".*[a-zA-Z].*") || !password.matches(".*\\d.*")) {
            this.passwordEdit.setError("Password must be at least 8 characters and include at least 1 letter and 1 number.");
            return false;
        }
        return true;
    }
}