package com.birzeit.androidproject;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserLogInActivity extends AppCompatActivity {

    private SharedPrefManager sharedPrefManager;
    private EditText email, password;
    private CheckBox rememberMe;
    private UserDataBase dataBaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_log_in);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        rememberMe = findViewById(R.id.rememberMe);
        Button loginButton = findViewById(R.id.loginButton);
        Button signUpButton = findViewById(R.id.signUpButton);
        ImageView back = findViewById(R.id.back);
        sharedPrefManager = SharedPrefManager.getInstance(this);
        dataBaseHelper = new UserDataBase(this);
        TextView forgetPassword = findViewById(R.id.forgetPassword);

        // Read the email from shared preferences
        email.setText(sharedPrefManager.readString("Email", ""));

        back.setOnClickListener(v -> {
            Intent intent = new Intent(UserLogInActivity.this, UserSignupLoginActivity.class);
            UserLogInActivity.this.startActivity(intent);
            finish();
        });

        loginButton.setOnClickListener(v -> handleLogin());

        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(UserLogInActivity.this, UserSignUpActivity.class);
            startActivity(intent);
        });
        forgetPassword.setOnClickListener(v -> handleForgetPassword());
    }

    private void handleLogin() {
        String emailStr = email.getText().toString().trim();
        String passwordStr = password.getText().toString().trim();

        if (emailStr.isEmpty()) {
            email.setError("Email is required");
            return;
        }

        if (passwordStr.isEmpty()) {
            password.setError("Password is required");
            return;
        }

        // Hash the password
        String hashedPassword = hashPassword(passwordStr);
        if (hashedPassword == null) {
            Toast.makeText(this, "Error hashing password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if email exists in the database
        Cursor cursor = dataBaseHelper.getUser(emailStr);
        if (cursor.getCount() == 0) {
            email.setError("Email not found");
            return;
        }

        cursor.moveToFirst();
        String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow("password"));
        if (!hashedPassword.equals(storedPassword)) {
            password.setError("Incorrect password");
            return;
        }

        // Retrieve user information
        String firstName = cursor.getString(cursor.getColumnIndexOrThrow("first_name"));
        String lastName = cursor.getString(cursor.getColumnIndexOrThrow("last_name"));
        String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow("phone_number"));
        String gender = cursor.getString(cursor.getColumnIndexOrThrow("gender"));
        boolean isAdmin = cursor.getInt(cursor.getColumnIndexOrThrow("is_admin")) > 0;

        // Save email in shared preferences if "Remember Me" is checked
        if (rememberMe.isChecked()) {
            sharedPrefManager.writeString("Email", emailStr);
        }
        UserDataBase userDataBase = new UserDataBase(this);
        userDataBase.insertInitialAdmin();  // Call this method if you haven't initialized your admin before

// Redirect based on user type
        Intent intent;
        if (isAdmin) {
            // Redirect to admin home activity
            intent = new Intent(UserLogInActivity.this, AdminHomeActivity.class);
            intent.putExtra("email", emailStr);
            intent.putExtra("fullName", firstName + " " + lastName);  // Adding fullName
        } else {
            // Redirect to user home activity
            intent = new Intent(UserLogInActivity.this, UserHomeActivity.class);
            intent.putExtra("email", emailStr);
            intent.putExtra("fullName", firstName + " " + lastName);
        }
        startActivity(intent);
        finish();

    }


    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());

            // Convert the byte array to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedPassword) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    private void handleForgetPassword() {
        // Show an alert dialog with instructions to contact support for password reset
        new AlertDialog.Builder(this)
                .setTitle("Forgot Password")
                .setMessage("Please contact support to reset your password.")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }

}