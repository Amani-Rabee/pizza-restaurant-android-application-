package com.birzeit.androidproject;

import androidx.annotation.NonNull;

public interface OrderViewHolder {
    void onBindViewHolder(@NonNull OrderAdapter.OrderViewHolder holder, int position);

    void bind(Order order);
}
